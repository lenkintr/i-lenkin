var searchData=
[
  ['pure_5fyellow',['PURE_YELLOW',['../_t_x_m___lib_8cpp.html#a42d3c9255d016c762abd9075d21d8740',1,'TXM_Lib.cpp']]]
];
