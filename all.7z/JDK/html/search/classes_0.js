var searchData=
[
  ['color',['color',['../structcolor.html',1,'']]]
];
